#ifndef ENCODERS_H
#define ENCODERS_H

#include <stdint.h>

/**
 * Initialise both rotary encoders (Enc0 = ZOOM on GP0/GP1, Enc1 = ITER on GP3/GP4).
 * Configures GPIO inputs with internal pull-ups and installs edge-triggered ISR.
 * Call once at startup, before the main loop.
 */
void encoders_init(void);

/**
 * Atomically read and clear the accumulated delta for encoder `idx` (0 or 1).
 *
 * Returns signed detent count since the last call:
 *   positive = clockwise  (zoom in / increase max_iter)
 *   negative = counter-clockwise
 *
 * EC11 encoders produce 4 quadrature transitions per mechanical detent.
 * This function already divides by 4, so the return value is in detents.
 * If your encoder reports double the expected count, the part produces
 * 2 transitions/detent — change the divisor in encoders.c accordingly.
 */
int32_t encoders_take_delta(int encoder_idx);

#endif /* ENCODERS_H */

#ifndef BUTTONS_H
#define BUTTONS_H

#include <stdint.h>

/**
 * Initialise all 11 button GPIOs with internal pull-ups.
 * Buttons are wired active-LOW (button connects pin to GND).
 * Call once at startup before the main loop.
 */
void buttons_init(void);

/**
 * Poll all buttons and run the debounce filter.
 * Must be called at approximately 1 kHz (every 1 ms) for the 5 ms
 * debounce window to work correctly.
 */
void buttons_poll(void);

/**
 * Return the current debounced button bitmask.
 * Bit i = 1  ⟺  button i is currently pressed.
 *
 * Bit assignments (matches §5.2 of the build guide):
 *   Bit 0  NEXT      GP6
 *   Bit 1  BACK      GP7
 *   Bit 2  SELECT    GP8
 *   Bit 3  MODE      GP9
 *   Bit 4  PALETTE   GP10
 *   Bit 5  RESET     GP11
 *   Bit 6  ENC0_SW   GP2  (zoom-encoder push)
 *   Bit 7  ENC1_SW   GP5  (iter-encoder push)
 *   Bit 8  JOY_SW    GP12
 *   Bit 9  SPARE1    GP13
 *   Bit 10 SPARE2    GP14
 *   Bits 11-15 reserved, always 0
 */
uint16_t buttons_get_state(void);

#endif /* BUTTONS_H */

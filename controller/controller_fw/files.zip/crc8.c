#include "crc8.h"

/*
 * CRC8-CCITT bit-by-bit implementation.
 *
 * Polynomial : x^8 + x^2 + x + 1  (0x07)
 * Initial value: 0x00
 * Input / output reflection: none
 * Final XOR: none
 *
 * A table-driven version would be faster, but at 100 Hz over ~45-byte
 * payloads (~4500 bytes/s) the bit-by-bit version costs negligible CPU
 * on the RP2040 at 125 MHz.  Keep it simple; optimise if profiling shows
 * CRC is a bottleneck (it won't be).
 */
uint8_t crc8_ccitt(const uint8_t *buf, size_t len) {
    uint8_t crc = 0x00;
    for (size_t i = 0; i < len; i++) {
        crc ^= buf[i];
        for (int b = 0; b < 8; b++) {
            if (crc & 0x80) {
                crc = (uint8_t)((crc << 1) ^ 0x07);
            } else {
                crc = (uint8_t)(crc << 1);
            }
        }
    }
    return crc;
}

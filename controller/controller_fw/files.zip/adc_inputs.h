#ifndef ADC_INPUTS_H
#define ADC_INPUTS_H

#include <stdint.h>

/**
 * Initialise the ADC peripheral and configure the four analog GPIO pins:
 *   ADC0 / GP26  – Joystick X
 *   ADC1 / GP27  – Joystick Y
 *   ADC2 / GP28  – Pot 0  (CR / real-part parameter)
 *   ADC3 / GP29  – Pot 1  (CI / imag-part parameter)
 *
 * Call once at startup before the main loop.
 */
void adc_inputs_init(void);

/**
 * Sample all four ADC channels and update the IIR filter state.
 * Must be called at approximately 1 kHz (every 1 ms) for the filter
 * time-constant to match expectations.
 *
 * α = 1/8  ⟹  ~3 dB corner ≈ 125 Hz at 1 kHz sample rate.
 * This is enough to suppress 12-bit ADC noise without perceivable lag.
 */
void adc_inputs_sample(void);

/**
 * Joystick X axis: signed, centre-zero, post-deadzone.
 * Range: -2048 .. +2047.  Returns 0 when inside the deadzone.
 * Positive = physical right.
 */
int16_t adc_joy_x(void);

/**
 * Joystick Y axis: signed, centre-zero, post-deadzone.
 * Range: -2048 .. +2047.  Returns 0 when inside the deadzone.
 * Positive = physical up.
 * Note: the PS side maps screen Y (grows downward) — do not flip here.
 */
int16_t adc_joy_y(void);

/**
 * Pot 0 filtered value (unsigned, 0 = fully CCW, 4095 = fully CW).
 */
uint16_t adc_pot0(void);

/**
 * Pot 1 filtered value (unsigned, 0 = fully CCW, 4095 = fully CW).
 */
uint16_t adc_pot1(void);

/**
 * Re-centre the joystick using the current filtered readings as the
 * zero reference.  Call:
 *   1. Automatically on power-up (after a 200 ms settle + 50 samples).
 *   2. Manually when the user holds RESET + ENC0_SW for 1 s.
 */
void adc_joy_calibrate(void);

#endif /* ADC_INPUTS_H */

#ifndef CRC8_H
#define CRC8_H

#include <stddef.h>
#include <stdint.h>

/**
 * Compute CRC8-CCITT (polynomial 0x07, initial value 0x00) over `len`
 * bytes of `buf`.
 *
 * This is the checksum used in the FSCP packet format (§5.1 of the build
 * guide).  The PS-side `controller_driver.py` uses an identical algorithm;
 * both sides must agree on:
 *   - which bytes are covered (everything up to, but not including, the
 *     final ",<crc>\n" suffix — i.e. the payload string as built by snprintf)
 *   - initial CRC value (0x00)
 *   - polynomial (0x07)
 *
 * This is NOT CRC8-MAXIM/Dallas (poly 0x31) or CRC8-SAE-J1850 (poly 0x1D).
 * If you ever switch algorithms, update both sides simultaneously and bump
 * the frame magic to catch stale parsers.
 */
uint8_t crc8_ccitt(const uint8_t *buf, size_t len);

#endif /* CRC8_H */

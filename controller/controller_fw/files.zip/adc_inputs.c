#include "adc_inputs.h"
#include "hardware/adc.h"
#include "hardware/gpio.h"

/*
 * ADC channel → GPIO mapping:
 *   channel 0  GP26  joystick X
 *   channel 1  GP27  joystick Y
 *   channel 2  GP28  pot 0
 *   channel 3  GP29  pot 1
 *
 * The RP2040 ADC runs at 12-bit resolution (0..4095).
 */

/*
 * IIR (exponential moving average) filter state.
 * Stored as uint16_t; accuracy is fine because we're filtering an ADC
 * whose values are themselves 12-bit.
 *
 *   filt[ch] = filt[ch] + (raw - filt[ch]) >> 3
 *
 * α = 1/8  →  time constant ≈ 7.4 samples ≈ 7.4 ms at 1 kHz poll rate.
 * Enough to kill 1-2 LSB noise; not enough to feel sluggish.
 */
static uint16_t filt[4] = {0, 0, 0, 0};

/*
 * Joystick centre calibration.
 * Initialised to 2048 (mid-scale) and refined by adc_joy_calibrate().
 */
static int16_t joy_centre_x = 2048;
static int16_t joy_centre_y = 2048;

/*
 * Deadzone radius around centre for the joystick axes.
 * 80 / 4096 ≈ 2% of full scale each side, 4% total dead band.
 * Prevents tiny mechanical offsets from generating continuous motion.
 * Change to 160 (≈4% each side) if the joystick is particularly noisy.
 */
#define DEADZONE 80

/* ── Helpers ──────────────────────────────────────────────── */

/*
 * Apply a symmetric deadzone to a centre-zero joystick value.
 * Values inside ±DEADZONE become 0.  Values outside are shifted toward
 * zero by DEADZONE so the output is continuous (no step at the edge).
 */
static int16_t apply_deadzone(int16_t v) {
    if (v >  (int16_t)DEADZONE) return (int16_t)(v - DEADZONE);
    if (v < -(int16_t)DEADZONE) return (int16_t)(v + DEADZONE);
    return 0;
}

/* ── Public API ───────────────────────────────────────────── */

void adc_inputs_init(void) {
    adc_init();
    adc_gpio_init(26);  /* ADC0 – joystick X */
    adc_gpio_init(27);  /* ADC1 – joystick Y */
    adc_gpio_init(28);  /* ADC2 – pot 0      */
    adc_gpio_init(29);  /* ADC3 – pot 1      */
}

void adc_inputs_sample(void) {
    for (int ch = 0; ch < 4; ch++) {
        adc_select_input((uint)ch);
        uint16_t raw = adc_read();  /* 0..4095 */

        /* IIR: filt += (raw - filt) / 8  (right-shift 3 = divide by 8) */
        filt[ch] = (uint16_t)(filt[ch] + (int32_t)((int32_t)raw - (int32_t)filt[ch]) / 8);
    }
}

int16_t adc_joy_x(void) {
    return apply_deadzone((int16_t)filt[0] - joy_centre_x);
}

int16_t adc_joy_y(void) {
    return apply_deadzone((int16_t)filt[1] - joy_centre_y);
}

uint16_t adc_pot0(void) { return filt[2]; }
uint16_t adc_pot1(void) { return filt[3]; }

void adc_joy_calibrate(void) {
    /*
     * Capture the current filtered readings as the "neutral" reference.
     * The filter should have been running for at least 50 ms before this
     * is called so the IIR has settled.
     */
    joy_centre_x = (int16_t)filt[0];
    joy_centre_y = (int16_t)filt[1];
}
